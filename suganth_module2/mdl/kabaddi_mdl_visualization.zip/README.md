# Kabaddi MDL Visualization (React + Vite)

This is a lightweight React app that computes a simple MDL-driven selection among candidate models
(Null, Per-player, Hierarchical shrinkage) and produces a ranked hierarchy of raiders from Team A vs Team B.

How to use:
1. Copy your JSON files into `public/data/`:
   - `season_1_matches.json` ... `season_12_matches.json`  (from each_match_data)
   - `prokabaddi_commentary_season5plus.json`             (from commentary_output/play_by_play/)
   - (optional) `season_index.json` or `teams_list.json` for faster indexing

2. Install and run:
   ```
   npm install
   npm run dev
   ```
3. Open http://localhost:5173 and enter Team A and Team B, then click "Load & Compute".

Notes:
- This app runs the MDL approximations in the browser. For large datasets, preprocess server-side.
- The MDL math implemented is an approximation using Gaussian residuals + BIC-like penalty (bits).
