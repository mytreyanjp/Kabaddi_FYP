import React, {useEffect, useState} from 'react'
import Hierarchy from './components/Hierarchy'

export default function App(){
  const [teamA, setTeamA] = useState('Patna Pirates')
  const [teamB, setTeamB] = useState('Tamil Thalaivas')
  const [status, setStatus] = useState('idle')
  const [dataSummary, setDataSummary] = useState(null)

  useEffect(()=> {
    // Preload team list from sample - user should drop their JSONs into public/data/
    fetch('/data/teams_list.json').then(r=>r.json()).then(js=>setDataSummary(js)).catch(()=>setDataSummary(null))
  },[])

  return (
    <div className="app">
      <div className="card">
        <h1>Kabaddi MDL — Raider Hierarchy Visualization</h1>
        <div className="muted">Place your JSON files in <code>public/data/</code>. Then click <b>Load & Compute</b>.</div>
        <div className="controls" style={{marginTop:12}}>
          <input className="select" value={teamA} onChange={e=>setTeamA(e.target.value)} placeholder="Team A (select)"/>
          <input className="select" value={teamB} onChange={e=>setTeamB(e.target.value)} placeholder="Team B (select)"/>
          <button onClick={()=>setStatus('loading') || window.dispatchEvent(new CustomEvent('mdl-run',{detail:{teamA,teamB}}))}>Load & Compute</button>
        </div>
        <div className="muted" style={{marginTop:8}}>
          Example teams: Patna Pirates, Tamil Thalaivas, Bengaluru Bulls, Jaipur Pink Panthers...
        </div>
      </div>

      <Hierarchy />

      <div style={{fontSize:12,color:'#94a3b8',marginTop:8}}>Notes: This app runs MDL-model selection in the browser (simple approximations). For large JSONs you may want to run preprocessing on a server.</div>
    </div>
  )
}
