import React, {useEffect, useState} from 'react'

// Utilities for MDL calculations (bits)
function nll_bits_gaussian(residuals){
  const N = residuals.length
  if(N===0) return Infinity
  // mean square
  let s2=0
  for(const r of residuals) s2 += r*r
  s2 = s2 / N
  const nll_nat = 0.5 * N * (Math.log(2*Math.PI*s2) + 1.0)
  return nll_nat / Math.log(2)
}
function bic_penalty_bits(k,N){
  if(N<=1) return 0
  return 0.5 * k * Math.log(N) / Math.log(2)
}

// Simple JS helpers
function mean(a){ if(a.length===0) return 0; return a.reduce((s,x)=>s+x,0)/a.length }
function std(a){ const m = mean(a); return Math.sqrt(mean(a.map(x=>(x-m)*(x-m)))) }

// Read match list file to get matches between two teams (all_match_data files should be merged externally)
async function findMatchIds(teamA, teamB){
  // The app expects the user to place a small index file teams_list.json referencing match IDs,
  // but we'll also attempt to scan all season summary files from /data/
  const matchIds = new Set()
  try {
    const resp = await fetch('/data/season_index.json')
    if(resp.ok){
      const idx = await resp.json()
      // idx expected format: { seasons: { "1": [{match_id, teams:[..]} ...] } }
      for(const s of Object.keys(idx.seasons||{})){
        for(const m of idx.seasons[s]){
          const teams = (m.team_a?.name || m.teams?.map(t=>t.team_name) || []).map(x=>String(x))
          if(teams.includes(teamA) && teams.includes(teamB)){
            matchIds.add(m.match_id || m.match_id_str || (m.match_id+''))
          }
        }
      }
    }
  }catch(e){}
  return Array.from(matchIds)
}

// Load per-match player stats from each_match_data aggregated files in /data/
async function loadPlayerRowsForMatches(matchIds){
  const rows = []
  // We'll try to read season_1..12_matches.json if present
  for(let s=1;s<=12;s++){
    try{
      const p = `/data/season_${s}_matches.json`
      const resp = await fetch(p)
      if(!resp.ok) continue
      const js = await resp.json()
      for(const m of js){
        if(matchIds.includes(m.match_id)){
          for(const team of (m.teams||[])){
            for(const pl of (team.players||[])){
              // normalize raiders only
              const cat = (pl.category||'').toLowerCase()
              if(!cat.includes('raider') && !cat.includes('all rounder')) continue
              rows.push({
                match_id: m.match_id,
                season: s,
                team: team.team_name || team.team_name,
                opponent: js.find(mm=>mm.match_id===m.match_id) ? ( (mmOpp = mmOpp = null) , ( ( (m.team_stats && Object.keys(m.team_stats).length>0) ? '' : '' ) ) ) : '',
                player: pl.name,
                points: Number(pl['Total Pts'] || pl['points'] || 0),
                succ_raids: Number(pl['Successful Raids'] || pl['Successful Raid'] || pl['SuccessfulRaids'] || 0),
                total_raids: Number(pl['Total Raids'] || pl['Total Raids'] || 0),
                bonus: Number(pl['Bonus Pts'] || 0),
                touch: Number(pl['Touch Pts'] || 0)
              })
            }
          }
        }
      }
    }catch(e){
      // ignore missing files
    }
  }
  return rows
}

// Build per-player aggregated observations for TeamA vs TeamB
function buildObs(rows, teamA, teamB){
  const filtered = rows.filter(r=>r.team===teamA) // we'll rely on match filtering earlier
  const grouped = {}
  for(const r of filtered){
    grouped[r.player] = grouped[r.player] || []
    grouped[r.player].push(r.points)
  }
  const obs = []
  for(const p of Object.keys(grouped)){
    obs.push({player:p, ys: grouped[p]})
  }
  return obs
}

// Models
function model_null(obs){
  const ys_all = [].concat(...obs.map(o=>o.ys))
  const mu = mean(ys_all)
  const residuals = ys_all.map(y=>y-mu)
  const nll = nll_bits_gaussian(residuals)
  const k = 1
  const pen = bic_penalty_bits(k, ys_all.length)
  return {dl: nll+pen, params:{mu}}
}

function model_per_player(obs){
  let residuals=[]
  let k=0; let N=0; const params={}
  for(const o of obs){
    const mu = mean(o.ys)
    params[o.player]=mu
    residuals = residuals.concat(o.ys.map(y=>y-mu))
    k+=1; N+=o.ys.length
  }
  const nll = nll_bits_gaussian(residuals)
  const pen = bic_penalty_bits(k, Math.max(1,N))
  return {dl: nll+pen, params}
}

function model_hierarchical_shrinkage(obs){
  const all = [].concat(...obs.map(o=>o.ys))
  if(all.length===0) return {dl:Infinity, params:{}}
  const mu0 = mean(all)
  const pooledVar = mean(all.map(y=> (y-mu0)*(y-mu0) ))
  // between-player variance estimate
  const means = obs.map(o=>mean(o.ys))
  const S2 = mean(means.map(m=> (m-mean(means))*(m-mean(means)) ))
  const tau2 = Math.max(S2 - (pooledVar/Math.max(1, mean(obs.map(o=>o.ys.length)))), 1e-8)
  const params = {}
  let residuals=[]
  for(const o of obs){
    const n = Math.max(1, o.ys.length)
    const sigma2 = pooledVar
    const w = tau2 / (tau2 + sigma2 / n)
    const mu_shr = w * mean(o.ys) + (1-w) * mu0
    params[o.player]=mu_shr
    residuals = residuals.concat(o.ys.map(y=>y-mu_shr))
  }
  const nll = nll_bits_gaussian(residuals)
  const k = 2
  const pen = bic_penalty_bits(k, all.length)
  return {dl: nll+pen, params}
}

export default function Hierarchy(){
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  useEffect(()=>{
    function handler(e){
      run(e.detail.teamA, e.detail.teamB)
    }
    window.addEventListener('mdl-run', handler)
    return ()=> window.removeEventListener('mdl-run', handler)
  },[])

  async function run(teamA, teamB){
    setLoading(true)
    setResult(null)
    // find match ids (best-effort)
    const matchIds = await findMatchIds(teamA, teamB)
    // load rows
    const rows = await loadPlayerRowsForMatches(matchIds)
    const obs = buildObs(rows, teamA, teamB)
    // evaluate models
    const mnull = model_null(obs)
    const mplayer = model_per_player(obs)
    const mhier = model_hierarchical_shrinkage(obs)
    const results = [
      {name:'Null', ...mnull},
      {name:'PerPlayer', ...mplayer},
      {name:'Hierarchical', ...mhier}
    ]
    results.sort((a,b)=>a.dl-b.dl)
    const best = results[0]
    // build ranking from best.params
    const ranking = Object.keys(best.params||{}).map(p=>({
      player:p,
      predicted: best.params[p]
    })).sort((a,b)=>b.predicted - a.predicted)
    setResult({models:results, best:best.name, dl:best.dl, ranking})
    setLoading(false)
  }

  return (
    <div className="card">
      <h2>Results</h2>
      {loading && <div className="muted">Computing MDL — this runs in the browser.</div>}
      {!loading && !result && <div className="muted">Click "Load & Compute" to run MDL over your data files (put them in /public/data/)</div>}
      {result && <>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <div>
            <div className="muted">Best Model: <b>{result.best}</b></div>
            <div className="muted">DL (bits): <b>{result.dl.toFixed(2)}</b></div>
          </div>
        </div>

        <h3 style={{marginTop:12}}>Player Rankings</h3>
        <table>
          <thead><tr><th>Rank</th><th>Player</th><th>ModelMean</th><th>Visual</th></tr></thead>
          <tbody>
            {result.ranking.map((r,i)=>(
              <tr key={r.player}>
                <td>{i+1}</td>
                <td>{r.player}</td>
                <td>{(r.predicted||0).toFixed(2)}</td>
                <td style={{width:240}}>
                  <div className="bar" style={{width: Math.max(6, Math.min(100, (r.predicted||0)*3)) + '%'}}></div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <h3 style={{marginTop:12}}>Model Comparison</h3>
        <table>
          <thead><tr><th>Model</th><th>DL (bits)</th></tr></thead>
          <tbody>
            {result.models.map(m=>(
              <tr key={m.name}><td>{m.name}</td><td>{m.dl.toFixed(2)}</td></tr>
            ))}
          </tbody>
        </table>
      </>}
    </div>
  )
}
