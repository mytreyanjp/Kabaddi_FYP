# Tactical Insights for Bhavani Rajput vs Patna Pirates

### 🧠 Tactical Report for Bhavani Rajput vs Patna Pirates

**Total Patterns Analyzed:** 10

- Bhavani Rajput frequently engages in Do-or-Die raids — useful for high-pressure moments.
- Bonus attempts are part of Bhavani Rajput's strategy — can exploit weak corners or single defenders.
- Lower success ratio suggests Bhavani Rajput struggles to convert raids against Patna Pirates’s defense.

### 🏹 Recommendations:

⚠️ Avoid excessive Do-or-Die raids; defense adapts quickly.
💡 Encourage bonus attempts early in the raid clock.
❌ Review defensive setups; too many non-scoring attempts.

---

| Pattern                                             |   Support |   Gain | Summary                                                                                                                                                               |
|:----------------------------------------------------|----------:|-------:|:----------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Do-or-Die raid (unknown) → Do-or-Die raid (unknown) |         4 |      3 | This pattern (Do-or-Die raid (unknown) → Do-or-Die raid (unknown)) occurs 4 times and represents a frequent and advantageous behavior (neutral or non-scoring trend). |
| Empty raid (unknown) → Empty raid (unknown)         |         4 |      3 | This pattern (Empty raid (unknown) → Empty raid (unknown)) occurs 4 times and represents a frequent and advantageous behavior (neutral or non-scoring trend).         |
| Empty raid (unknown) → Regular raid (success)       |         4 |      3 | This pattern (Empty raid (unknown) → Regular raid (success)) occurs 4 times and represents a frequent and advantageous behavior (positive scoring tendency).          |
| Empty raid (unknown)                                |        13 |     -1 | This pattern (Empty raid (unknown)) occurs 13 times and represents a common but low-impact behavior (neutral or non-scoring trend).                                   |
| Regular raid (success)                              |        11 |     -1 | This pattern (Regular raid (success)) occurs 11 times and represents a common but low-impact behavior (positive scoring tendency).                                    |
| Do-or-Die raid (unknown)                            |         6 |     -1 | This pattern (Do-or-Die raid (unknown)) occurs 6 times and represents a common but low-impact behavior (neutral or non-scoring trend).                                |
| Bonus attempt (success)                             |         5 |     -1 | This pattern (Bonus attempt (success)) occurs 5 times and represents a common but low-impact behavior (positive scoring tendency).                                    |
| Bonus attempt (success)                             |         4 |     -1 | This pattern (Bonus attempt (success)) occurs 4 times and represents a common but low-impact behavior (positive scoring tendency).                                    |
| Do-or-Die raid (unknown)                            |         3 |     -1 | This pattern (Do-or-Die raid (unknown)) occurs 3 times and represents a common but low-impact behavior (neutral or non-scoring trend).                                |
| Bonus attempt (success)                             |         3 |     -1 | This pattern (Bonus attempt (success)) occurs 3 times and represents a common but low-impact behavior (positive scoring tendency).                                    |