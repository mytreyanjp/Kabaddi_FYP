# Tactical Insights for Aslam Inamdar vs U P Yoddha

### 🧠 Tactical Report for Aslam Inamdar vs U P Yoddha

**Total Patterns Analyzed:** 10

- Aslam Inamdar frequently engages in Do-or-Die raids — useful for high-pressure moments.
- Bonus attempts are part of Aslam Inamdar's strategy — can exploit weak corners or single defenders.
- Higher success ratio suggests Aslam Inamdar performs effectively against U P Yoddha.

### 🏹 Recommendations:

✅ Use in Do-or-Die situations for momentum shifts.
💡 Encourage bonus attempts early in the raid clock.

---

| Pattern                                                                        |   Support |   Gain | Summary                                                                                                                                                                                       |
|:-------------------------------------------------------------------------------|----------:|-------:|:----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Do-or-Die raid (success) → Do-or-Die raid (success) → Do-or-Die raid (unknown) |         5 |      9 | This pattern (Do-or-Die raid (success) → Do-or-Die raid (success) → Do-or-Die raid (unknown)) occurs 5 times and represents a frequent and advantageous behavior (positive scoring tendency). |
| Do-or-Die raid (success) → Do-or-Die raid (success)                            |         9 |      8 | This pattern (Do-or-Die raid (success) → Do-or-Die raid (success)) occurs 9 times and represents a frequent and advantageous behavior (positive scoring tendency).                            |
| Do-or-Die raid (unknown) → Do-or-Die raid (unknown)                            |         9 |      8 | This pattern (Do-or-Die raid (unknown) → Do-or-Die raid (unknown)) occurs 9 times and represents a frequent and advantageous behavior (neutral or non-scoring trend).                         |
| Do-or-Die raid (success) → Do-or-Die raid (unknown)                            |         8 |      7 | This pattern (Do-or-Die raid (success) → Do-or-Die raid (unknown)) occurs 8 times and represents a frequent and advantageous behavior (positive scoring tendency).                            |
| Do-or-Die raid (success) → Do-or-Die raid (unknown) → Do-or-Die raid (unknown) |         4 |      7 | This pattern (Do-or-Die raid (success) → Do-or-Die raid (unknown) → Do-or-Die raid (unknown)) occurs 4 times and represents a frequent and advantageous behavior (positive scoring tendency). |
| Do-or-Die raid (unknown) → Do-or-Die raid (success)                            |         7 |      6 | This pattern (Do-or-Die raid (unknown) → Do-or-Die raid (success)) occurs 7 times and represents a frequent and advantageous behavior (positive scoring tendency).                            |
| Bonus attempt (success) → Do-or-Die raid (success)                             |         4 |      3 | This pattern (Bonus attempt (success) → Do-or-Die raid (success)) occurs 4 times and represents a frequent and advantageous behavior (positive scoring tendency).                             |
| Do-or-Die raid (success)                                                       |        22 |     -1 | This pattern (Do-or-Die raid (success)) occurs 22 times and represents a common but low-impact behavior (positive scoring tendency).                                                          |
| Do-or-Die raid (unknown)                                                       |        21 |     -1 | This pattern (Do-or-Die raid (unknown)) occurs 21 times and represents a common but low-impact behavior (neutral or non-scoring trend).                                                       |
| Bonus attempt (success)                                                        |         7 |     -1 | This pattern (Bonus attempt (success)) occurs 7 times and represents a common but low-impact behavior (positive scoring tendency).                                                            |