# Tactical Insights for Ajay Thakur vs Patna Pirates

### 🧠 Tactical Report for Ajay Thakur vs Patna Pirates

**Total Patterns Analyzed:** 10

- Ajay Thakur frequently engages in Do-or-Die raids — useful for high-pressure moments.
- Bonus attempts are part of Ajay Thakur's strategy — can exploit weak corners or single defenders.
- Higher success ratio suggests Ajay Thakur performs effectively against Patna Pirates.

### 🏹 Recommendations:

✅ Use in Do-or-Die situations for momentum shifts.
💡 Encourage bonus attempts early in the raid clock.

---

| Pattern                                                                        |   Support |   Gain | Summary                                                                                                                                                                                       |
|:-------------------------------------------------------------------------------|----------:|-------:|:----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Do-or-Die raid (unknown) → Do-or-Die raid (success)                            |        13 |     12 | This pattern (Do-or-Die raid (unknown) → Do-or-Die raid (success)) occurs 13 times and represents a frequent and advantageous behavior (positive scoring tendency).                           |
| Do-or-Die raid (unknown) → Do-or-Die raid (success) → Do-or-Die raid (unknown) |         6 |     11 | This pattern (Do-or-Die raid (unknown) → Do-or-Die raid (success) → Do-or-Die raid (unknown)) occurs 6 times and represents a frequent and advantageous behavior (positive scoring tendency). |
| Do-or-Die raid (success) → Do-or-Die raid (unknown)                            |        11 |     10 | This pattern (Do-or-Die raid (success) → Do-or-Die raid (unknown)) occurs 11 times and represents a frequent and advantageous behavior (positive scoring tendency).                           |
| Do-or-Die raid (success) → Do-or-Die raid (success)                            |        10 |      9 | This pattern (Do-or-Die raid (success) → Do-or-Die raid (success)) occurs 10 times and represents a frequent and advantageous behavior (positive scoring tendency).                           |
| Do-or-Die raid (unknown) → Do-or-Die raid (unknown) → Do-or-Die raid (success) |         5 |      9 | This pattern (Do-or-Die raid (unknown) → Do-or-Die raid (unknown) → Do-or-Die raid (success)) occurs 5 times and represents a frequent and advantageous behavior (positive scoring tendency). |
| Do-or-Die raid (unknown) → Do-or-Die raid (unknown)                            |         9 |      8 | This pattern (Do-or-Die raid (unknown) → Do-or-Die raid (unknown)) occurs 9 times and represents a frequent and advantageous behavior (neutral or non-scoring trend).                         |
| Do-or-Die raid (unknown)                                                       |        29 |     -1 | This pattern (Do-or-Die raid (unknown)) occurs 29 times and represents a common but low-impact behavior (neutral or non-scoring trend).                                                       |
| Do-or-Die raid (success)                                                       |        27 |     -1 | This pattern (Do-or-Die raid (success)) occurs 27 times and represents a common but low-impact behavior (positive scoring tendency).                                                          |
| Do-or-Die raid (success)                                                       |         4 |     -1 | This pattern (Do-or-Die raid (success)) occurs 4 times and represents a common but low-impact behavior (positive scoring tendency).                                                           |
| Bonus attempt (success)                                                        |         4 |     -1 | This pattern (Bonus attempt (success)) occurs 4 times and represents a common but low-impact behavior (positive scoring tendency).                                                            |