# Tactical Insights for Anand Patil vs Puneri Paltan

### 🧠 Tactical Report for Anand Patil vs Puneri Paltan

**Total Patterns Analyzed:** 10

- Anand Patil frequently engages in Do-or-Die raids — useful for high-pressure moments.
- Bonus attempts are part of Anand Patil's strategy — can exploit weak corners or single defenders.
- Higher success ratio suggests Anand Patil performs effectively against Puneri Paltan.

### 🏹 Recommendations:

⚠️ Avoid excessive Do-or-Die raids; defense adapts quickly.
💡 Encourage bonus attempts early in the raid clock.

---

| Pattern                                                                                                   |   Support |   Gain | Summary                                                                                                                                                                                                                     |
|:----------------------------------------------------------------------------------------------------------|----------:|-------:|:----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Do-or-Die raid (unknown) → Do-or-Die raid (unknown) → Do-or-Die raid (unknown) → Do-or-Die raid (unknown) |         3 |      8 | This pattern (Do-or-Die raid (unknown) → Do-or-Die raid (unknown) → Do-or-Die raid (unknown) → Do-or-Die raid (unknown)) occurs 3 times and represents a frequent and advantageous behavior (neutral or non-scoring trend). |
| Do-or-Die raid (unknown) → Do-or-Die raid (unknown) → Do-or-Die raid (unknown)                            |         4 |      7 | This pattern (Do-or-Die raid (unknown) → Do-or-Die raid (unknown) → Do-or-Die raid (unknown)) occurs 4 times and represents a frequent and advantageous behavior (neutral or non-scoring trend).                            |
| Do-or-Die raid (unknown) → Do-or-Die raid (unknown)                                                       |         7 |      6 | This pattern (Do-or-Die raid (unknown) → Do-or-Die raid (unknown)) occurs 7 times and represents a frequent and advantageous behavior (neutral or non-scoring trend).                                                       |
| Do-or-Die raid (unknown)                                                                                  |        12 |     -1 | This pattern (Do-or-Die raid (unknown)) occurs 12 times and represents a common but low-impact behavior (neutral or non-scoring trend).                                                                                     |
| Do-or-Die raid (success)                                                                                  |         3 |     -1 | This pattern (Do-or-Die raid (success)) occurs 3 times and represents a common but low-impact behavior (positive scoring tendency).                                                                                         |
| Bonus attempt (success)                                                                                   |         1 |     -1 | This pattern (Bonus attempt (success)) occurs 1 times and represents a common but low-impact behavior (positive scoring tendency).                                                                                          |
| Bonus attempt (success)                                                                                   |         1 |     -1 | This pattern (Bonus attempt (success)) occurs 1 times and represents a common but low-impact behavior (positive scoring tendency).                                                                                          |
| Bonus attempt (success)                                                                                   |         1 |     -1 | This pattern (Bonus attempt (success)) occurs 1 times and represents a common but low-impact behavior (positive scoring tendency).                                                                                          |
| Bonus attempt (success)                                                                                   |         1 |     -1 | This pattern (Bonus attempt (success)) occurs 1 times and represents a common but low-impact behavior (positive scoring tendency).                                                                                          |
| Bonus attempt (success)                                                                                   |         1 |     -1 | This pattern (Bonus attempt (success)) occurs 1 times and represents a common but low-impact behavior (positive scoring tendency).                                                                                          |